//
//  AppDelegate.h
//  Proyecto
//
//  Created by Jobando on 30/3/17.
//  Copyright © 2017 CNFL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

