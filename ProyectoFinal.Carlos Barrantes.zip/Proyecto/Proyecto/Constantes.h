//
//  Constantes.h
//  Proyecto
//
//  Created by Jobando on 30/3/17.
//  Copyright © 2017 CNFL. All rights reserved.
//

#ifndef Constantes_h
#define Constantes_h

#define API_KEY @"a1c27850d0p09c204adf4a5bde92c11de9e1717ad"
#define API_URL @""
#define URL_LOGIN @"https://agenciavirtual.cnfl.go.cr/app2/service/lg/"



#endif /* Constantes_h */
